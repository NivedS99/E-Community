<?php
$servername = "localhost";
$username = "root";
$password="";
$dbname = "e-community";

$conn = mysqli_connect($servername, $username, $password) or die('Connection Failed');
mysqli_select_db($conn,$dbname) or die('No database found');

if(isset($_POST['signup']))
{
   $s1=$_POST['rname'];
   $s2=$_POST['number1'];
   $s3=$_POST['eid'];
   $s4=$_POST['house_no'];
 
   $s6=$_POST['uname'];
    $s7=$_POST['pwd'];
    $s8=$_POST['pwd1'];
   $s9="resident";

   $error = 0;
  
  $check_mobile=mysqli_query($conn,"SELECT * FROM residenttemp_tb WHERE number1='$s2'");
  $check_house=mysqli_query($conn,"SELECT house_no FROM residenttemp_tb WHERE house_no='$s4'");
   $check_user=mysqli_query($conn,"SELECT uname FROM  residenttemp_tb WHERE uname='$s6'");

  if (mysqli_num_rows($check_mobile)>0)
   {
    echo "<script> alert('Mobile Number Already Exist');</script>";
    echo "<script>window.history.back();</script>";
    $error += 1;
  }
   else  if (mysqli_num_rows($check_house)>0)
   {
    echo "<script> alert('House is not vacant');</script>";
    echo "<script>window.history.back();</script>";
    $error += 1;
  }
  else if(mysqli_num_rows($check_user) > 0) {
     echo "<script> alert('Username Already Exist');</script>";
     echo "<script>window.history.back();</script>";
     $error += 1;
   }
   
  else if($s7 != $s8)
  {
    echo "<script> alert('Both passwords do not match');</script>";
    echo "<script>window.history.back();</script>";
    $error += 1;
  }
  
  else if($error==0)
  {
      $query = "INSERT INTO residenttemp_tb (rname,number1,eid,house_no,uname,type) VALUES ('$s1','$s2','$s3','$s4','$s6','$s9')";
      $run = mysqli_query($conn,$query) or die('registration not done');
      $query1 = "INSERT INTO login_tb (uname,password,type) VALUES ('$s6','$s7','$s9')";
      $run1= mysqli_query($conn,$query1) or die('details not inserted');
      $query2 = "UPDATE houses_tb SET vacancy='occupied' WHERE house_no='$s4'";
      $run2= mysqli_query($conn,$query2) or die('details not updated');
      if($run && $run1){
        echo "<script>alert('New Record Created Succesfully');</script>";
      }
  
      else{
        echo "<script>alert('Record not submitted');</script>";
      }
  

    }

}
if(isset($_POST['login']))
{
   $uname=$_POST['uname'];
  $pas=$_POST['password'];


    $query=mysqli_query($conn,"SELECT * FROM login_tb WHERE uname='$uname' AND password='$pas'");


  if (mysqli_num_rows($query)>0) 
    
    {

      $row=mysqli_fetch_assoc($query);
      $_SESSION["user_name"]=$row['uname'];
      $_SESSION["type_id"]=$row['type'];
      
      if($row['type']=="admin")
      {header("location:../trialadmin.php");}
       else
        {header("location:../userhome.php");}

    }

    else

    {

      echo "<script>alert('Invalid USERNAME or PASSWORD');</script>";

    }

  }


?>
<!DOCTYPE html> 
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login & Signup Form </title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
    <div class="wrapper">
      <div class="title-text">
        <div class="title login">Login Form</div>
        <div class="title signup">Signup Form</div>
      </div>
      <div class="form-container">
        <div class="slide-controls">
          <input type="radio" name="slide" id="login" checked>
          <input type="radio" name="slide" id="signup">
          <label for="login" class="slide login">Login</label>
          <label for="signup" class="slide signup">Signup</label>
          <div class="slider-tab"></div>
        </div>
        <br><br>
        <div class="form-inner">
          <form action="#" class="login" method="post">
            <div class="field">
              <input type="text" placeholder="Username" name="uname" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Password" name="password" required>
            </div>
            
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Login" name="login">
            </div>
            <div class="signup-link">Not a member? <a href="">Signup now</a></div>
          </form>
          <form action="#" method="post">
    <div class="field">
              <input type="text" placeholder="Name" name="rname" required>
            </div>
    <div class="field">
              <input type="text" placeholder="Number" name="number1"  minlength=10 maxlength=10 required>
            </div>
            <div class="field">
              <input type="email" placeholder="Email Address" name="eid" required>
            </div>
    <div class="field">
              <input type="text" placeholder="House No." name="house_no" required>
            </div>
    
    <div class="field">
              <input type="text" placeholder="username" name="uname" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Password" name="pwd" minlength=6 required>
            </div>
            <div class="field">
              <input type="password" placeholder="Confirm password" name="pwd1" minlength=6 required>
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Signup" name="signup">
            </div>
          </form>
        </div>
      </div>
    </div>

    <script>
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = (()=>{
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      });
      loginBtn.onclick = (()=>{
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      });
      signupLink.onclick = (()=>{
        signupBtn.click();
        return false;
      });
    </script>

  </body>
</html>